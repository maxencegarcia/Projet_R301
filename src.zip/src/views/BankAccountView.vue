<template>
  <div>
    <h1>Login</h1>

    <span>number</span><input v-model="number">
    <button @click="bankStore.getAccountAmount({number})">confirm</button>
    <p v-if="bankStore.accountAmount">{{bankStore.accountAmount}}</p>

    <button @click="bankStore.getAccountTransactions({number})">transactions</button>
    <ul v-if="bankStore.accountTransactions.length > 0">
      <li v-for="transaction in bankStore.accountTransactions" :key="transaction._id">
        {{ transaction.amount }} — {{ transaction.date.$date }}
      </li>
    </ul>
  </div>
</template>

<script setup>
import {ref} from "vue";
import {useShopStore} from "@/stores/shop.js";
import {useBankStore} from "@/stores/bank.js";

const number = ref('')
const bankStore = useBankStore()
</script>